﻿using System;
using System.Collections.Generic;
using System.IO;
using System.IO.Compression;
using System.Threading;

namespace ConsoleApplication1
{
    internal class Program
    {
        static List<Thread> thread_pool = new List<Thread>();
        static object activeLocker = new object();
        static int locker = 1;

        public static void Main(string[] args)
        {
            Console.WriteLine("Please enter the path to the folder: ");
            string path = Console.ReadLine();
            archiveFilesInFolder(new Parameters(path, path));
            bool wait = true;
            while (wait)
            {
                lock (activeLocker)
                {
                    if (locker == 0) wait = false;
                }
            }

                //Console.WriteLine("Exit... Active threads count: {0}.", locker);

            Console.ReadLine();
        }

        private static void archiveFilesInFolder(object obj)
        {
            lock (activeLocker)
            {
                Console.WriteLine("Thread #{0} is starting... Active threads count: {1}",
                    Thread.CurrentThread.ManagedThreadId, locker);
            }

            var parameters = (Parameters)obj;
            string targetFolderPath = parameters.TargetFolderPath;
            string newFolderPath = parameters.NewFolderPath;

            var directoryName = Path.GetFileName(targetFolderPath);
            var newDirectoryPath = Path.Combine(newFolderPath, directoryName);

            Directory.CreateDirectory(newDirectoryPath);

            var directories = Directory.GetDirectories(targetFolderPath);
            foreach (var directory in directories)
            {
                Thread thread = new Thread(archiveFilesInFolder);

                // Добавить новый поток в коллекцию
                lock (thread_pool)
                {
                    thread_pool.Add(thread);
                }

                lock (activeLocker)
                {
                    ++locker;
                }

                thread.Start(new Parameters(directory, newDirectoryPath));
            }

            var files = Directory.GetFiles(targetFolderPath);
            foreach (var file in files)
            {
                var name = Path.GetFileName(file);
                var newFile = string.Format("{0}\\{1}.zip", newDirectoryPath, Path.GetFileNameWithoutExtension(file));
                using (FileStream fs = new FileStream(newFile, FileMode.Create))
                {
                    using (ZipArchive arch = new ZipArchive(fs, ZipArchiveMode.Create))
                    {
                        arch.CreateEntryFromFile(file, name);
                    }
                }
            }


            lock (activeLocker)
            {
                --locker;
                Console.WriteLine("Thread #{0} is finishing... Active threads count: {1}.",
                    Thread.CurrentThread.ManagedThreadId, locker);
            }
        }

        private class Parameters
        {
            public string TargetFolderPath { get; }

            public string NewFolderPath { get; }


            public Parameters(string targetFolderPath, string newFolderPath)
            {
                TargetFolderPath = targetFolderPath;
                NewFolderPath = newFolderPath;
            }
        }
    }
}